


2. `npm install http-server -g` to get [simple HTTP file server](https://github.com/nodeapps/http-server),
 you may want to use Apache or any other
3. `http-server . -p 8010`
4. Open `http://localhost:8010/` to check if you see home page
